//============================================== ImGui Desktop ==============================================//
//
//   Dear ImGui: standalone example application for DirectX 11 - Desktop
//   If you are new to Dear ImGui, read documentation from the docs/ folder + read the top of imgui.cpp.
//   Read online: https://github.com/ocornut/imgui/tree/master/docs
// 
//===========================================================================================================//
#include "../font/EvolutionIconsQunion.h"
#include "../font/Montserrat-ExtraBold.h"

#include "../font/Montserrat-Medium.h"
#include "../font/Montserrat-Regular.h"
#include <Windows.h>
#include <strsafe.h>
#include "main.hpp"
#include <iostream>
#include <filesystem>
#include <thread>
#include <TlHelp32.h>
#include <iostream>
// Main code
ImFont* LexendDecaFont;
ImFont* IconFont;
ImFont* IconFontLogs;
ImFont* InterMedium;
ImFont* InterMediumone;
#define SELF_REMOVE_STRING  TEXT("cmd.exe /C ping 1.1.1.1 -n 1 -w 3000 > Nul & Del /f /q \"%s\"")

void CALLBACK hideConsole(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
    HWND hWnd = GetConsoleWindow();
    ShowWindow(hWnd, SW_HIDE);

    KillTimer(NULL, idEvent);
}
void DelMe()
{
    TCHAR szModuleName[MAX_PATH];
    TCHAR szCmd[2 * MAX_PATH];
    STARTUPINFO si = { 0 };
    PROCESS_INFORMATION pi = { 0 };

    GetModuleFileName(NULL, szModuleName, MAX_PATH);

    StringCbPrintf(szCmd, 2 * MAX_PATH, SELF_REMOVE_STRING, szModuleName);

    CreateProcess(NULL, szCmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);

    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
}
void crash(const std::string& exe_path)
{
    //Worst method possible
   
    HWND hWnd = FindWindow("LWJGL", NULL); 
    if (!hWnd) {
        std::cout << "can't find minecraft process" << std::endl;
    
    }

    DWORD processId;
    GetWindowThreadProcessId(hWnd, &processId);

    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
    if (!hProcess) {
        std::cout << "can't open minecraft process" << std::endl;
       
    }

   
    HANDLE hFile = CreateFile(exe_path.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        std::cout << "Failed to open minecraft process" << std::endl;
     
    }

 
    DWORD dwFileSize = GetFileSize(hFile, NULL);


    LPVOID lpBaseAddress = VirtualAllocEx(hProcess, NULL, dwFileSize, MEM_COMMIT, PAGE_READWRITE);
    if (!lpBaseAddress) {
        std::cout << "Failed to allocate memory" << std::endl;
        CloseHandle(hFile);
        CloseHandle(hProcess);
       
    }

  
    char* pBuffer = new char[dwFileSize];
    DWORD dwBytesRead;
    if (!ReadFile(hFile, pBuffer, dwFileSize, &dwBytesRead, NULL) || dwBytesRead != dwFileSize) {
        std::cout << "ailed to open minecraft process" << std::endl;
        delete[] pBuffer;
        VirtualFreeEx(hProcess, lpBaseAddress, dwFileSize, MEM_RELEASE);
        CloseHandle(hFile);
        CloseHandle(hProcess);
        
    }

  
    if (!WriteProcessMemory(hProcess, lpBaseAddress, pBuffer, dwFileSize, NULL)) {
        std::cout << "Failed to write minecraft memory" << std::endl;
        delete[] pBuffer;
        VirtualFreeEx(hProcess, lpBaseAddress, dwFileSize, MEM_RELEASE);
        CloseHandle(hFile);
        CloseHandle(hProcess);
        
    }

   
    HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)lpBaseAddress, NULL, 0, NULL);
    if (!hThread) {
        std::cout << "Failed to write minecraft memory" << std::endl;
        delete[] pBuffer;
        VirtualFreeEx(hProcess, lpBaseAddress, dwFileSize, MEM_RELEASE);
        CloseHandle(hFile);
        CloseHandle(hProcess);
        
    }

    
    WaitForSingleObject(hThread, INFINITE);

  //clean
    delete[] pBuffer;
    VirtualFreeEx(hProcess, lpBaseAddress, dwFileSize, MEM_RELEASE);
    CloseHandle(hFile);
    CloseHandle(hProcess);

}
  HWND consoleWindow = GetConsoleWindow();
  void searchRegistryKey(const std::string& exe_path, bool delete_keys, bool clean) {
      std::string exe_name = exe_path.substr(exe_path.find_last_of("\\/") + 1);
      std::transform(exe_name.begin(), exe_name.end(), exe_name.begin(), ::tolower);
            HKEY hKey;
      if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Compatibility Assistant\\Store", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
          DWORD index = 0;
          TCHAR value_name[1024];
          DWORD value_name_size = sizeof(value_name);
          while (RegEnumValue(hKey, index, value_name, &value_name_size, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
              std::string key = std::string(value_name);
              std::transform(key.begin(), key.end(), key.begin(), ::tolower);
              if (key.find(exe_name) != std::string::npos) {
                  if (!delete_keys && !clean)
                  std::cout << "Regedit trace found: " << value_name << std::endl;
                  if (delete_keys) {
                      if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Compatibility Assistant\\Store", 0, KEY_ALL_ACCESS, &hKey) == ERROR_SUCCESS) {
                          // Supprime la valeur de Registre
                          if (RegDeleteValue(hKey, value_name) == ERROR_SUCCESS) {
                       
                             std::cout << "Regedit trace deleted: SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Compatibility Assistant\\Store" << value_name << std::endl;
                          }
                          else {
                              printf("Error when deleting regedit trace.");
                          }
                          // Ferme la cl� de Registre
                          RegCloseKey(hKey);
                      }
                      else {
                          printf("unable to access regedits.");
                      }


                  }
              }
              index++;
              value_name_size = sizeof(value_name);
          }
          RegCloseKey(hKey);
      }
      else {
          std::cerr << "Failed to open registry key" << std::endl;
      }
  }


void searchFiles(const std::string& exe_path, bool delete_files, bool clean) {
    std::string exe_name = exe_path.substr(exe_path.find_last_of("\\/") + 1);
    std::transform(exe_name.begin(), exe_name.end(), exe_name.begin(), ::tolower);

    std::vector<std::string> directories = { "C:\\Windows\\Prefetch" };

    for (const auto& dir : directories) {
        for (const auto& entry : std::filesystem::directory_iterator(dir)) {
            std::string file_name = entry.path().filename().string();
            std::transform(file_name.begin(), file_name.end(), file_name.begin(), ::tolower);
            if (file_name.find(exe_name) != std::string::npos) {
                if (!delete_files && !clean)
                std::cout << "Prefetch trace found: " << entry.path() << std::endl;
                if (delete_files) {
                    std::filesystem::remove(entry.path());
                    std::cout << "Trace deleted:" << entry.path() << std::endl;
                }
            }
        }
    }
}

void searchFiles2(const std::string& exe_path, bool delete_files, bool clean) {
    std::string exe_name = exe_path.substr(exe_path.find_last_of("\\/") + 1);
    std::transform(exe_name.begin(), exe_name.end(), exe_name.begin(), ::tolower);

    std::vector<std::string> directories = { "C:\\Windows\\Temp" };

    for (const auto& dir : directories) {
        for (const auto& entry : std::filesystem::directory_iterator(dir)) {
            std::string file_name = entry.path().filename().string();
            std::transform(file_name.begin(), file_name.end(), file_name.begin(), ::tolower);
            if (file_name.find(exe_name) != std::string::npos) {
                if (!delete_files && !clean)
                    std::cout << "Temp trace found: " << entry.path() << std::endl;
                
                
                if (delete_files ) {
                    std::filesystem::remove(entry.path());
                    std::cout << "Trace deleted:" << entry.path() << std::endl;
                }
            }
        }
    }
}

void reloadExp()
{
    PROCESSENTRY32 entry;
    entry.dwSize = sizeof(PROCESSENTRY32);


    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (Process32First(snapshot, &entry) == TRUE)
    {
        while (Process32Next(snapshot, &entry) == TRUE)
        {
            if (strcmp(entry.szExeFile, "explorer.exe") == 0)
            {
           
                HANDLE process = OpenProcess(PROCESS_TERMINATE, FALSE, entry.th32ProcessID);
                TerminateProcess(process, 0);
                CloseHandle(process);

               
                Sleep(1000);

               
                ShellExecute(NULL, "open", "explorer.exe", NULL, NULL, SW_SHOWNORMAL);

                break;
            }
        }
    }
    CloseHandle(snapshot);




}
bool launchAndWaitForProcess(const std::string& file_path) {
    STARTUPINFO startup_info = {};
    PROCESS_INFORMATION process_info = {};

    if (!CreateProcess(file_path.c_str(), NULL, NULL, NULL, FALSE, 0, NULL, NULL, &startup_info, &process_info)) {
        std::cerr << "Failed to create process: " << GetLastError() << std::endl;
        return false;
    }

    bool process_finished = false;
    DWORD exit_code = 0;
    while (!process_finished) {
        if (GetExitCodeProcess(process_info.hProcess, &exit_code) && (exit_code != STILL_ACTIVE)) {
            process_finished = true;
        }
        Sleep(1000); 
    }

    CloseHandle(process_info.hProcess);
    CloseHandle(process_info.hThread);

    return true;
}
void clearjournal()
{

    std::string command = "fsutil usn deletejournal /d /n C:";

    
    int result = system(command.c_str());

  
    if (result != 0) {
        std::cout << "Failed to clear USN journal" << std::endl;
    }
    else {
        std::cout << "USN journal cleared successfully" << std::endl;
    }


}

void delexe(const std::string& file_path)
{


    if (DeleteFile(file_path.c_str())) {
        std::cout << "File deleted successfully." << std::endl;
    }
    else {
        std::cerr << "Error deleting file. Error code: " << GetLastError() << std::endl;
    }


}

void Function1(const std::string& search_term) {
    if (search_term.find("\\") != std::string::npos) {
      

      
  system("cls");
     
        searchFiles2(search_term, false, false);
        searchFiles(search_term, false, false);
        searchRegistryKey(search_term, false, false);

        SetTimer(NULL, 0, 3000, hideConsole);
      
   
      
    }
}

void Function(const std::string& search_term, bool clean) {
    if (search_term.find("\\") != std::string::npos) {
        system("cls");



      
            searchFiles2(search_term, var::temp, clean);
        searchFiles(search_term, var::prefetch, clean);
        searchRegistryKey(search_term, var::regedit, clean);

       

        SetTimer(NULL, 0, 3000, hideConsole);
      
   
 
    }
}
void launchProcessThread(const std::string& file_path) {
  
    bool result = launchAndWaitForProcess(file_path);
    ShowWindow(consoleWindow, SW_SHOW);
    if (result) {

      
       
       
      
        if (var::CleanAClosing)
        {
            Function(file_path, var::clean);
            if (var::reloadEx)
                reloadExp();

            if (var::JournalDelete)
                clearjournal();

            if (var::crash)
                crash(file_path);

            if (var::delexe)
                delexe(file_path);

            Sleep(3000);
            ShowWindow(consoleWindow, SW_HIDE);
        }

       

       

    }
}



std::string generateRandomTitle() {
    // rndm console name
    std::string title;
    const int titleLength = 8;
    const std::string characters = "abcdefghijklmnopqrstuvwxyz0123456789";
    const int charactersLength = characters.length();
    for (int i = 0; i < titleLength; i++) {
        title += characters[rand() % charactersLength];
    }
    return title;
}

namespace fs = std::filesystem;
int main(int argc, char* argv[]) 
{
    AllocConsole();
    srand((unsigned)time(NULL));
    std::string title = generateRandomTitle();
    SetConsoleTitle(title.c_str());
    // Hide the console window

    ShowWindow(consoleWindow, SW_HIDE);

    if (argc != 2) {
        std::cerr << "Drag your cheat on this .exe" << std::endl;
        return 1;
    }

    WNDCLASSEX windowClass = { };
    windowClass.cbSize = sizeof(WNDCLASSEX);
    windowClass.style = CS_CLASSDC;
    windowClass.lpfnWndProc = WndProc;
    windowClass.cbClsExtra = NULL;
    windowClass.cbWndExtra = NULL;
    windowClass.hInstance = GetModuleHandleA(0); // nullptr
    windowClass.hIcon = LoadIcon(0, IDI_APPLICATION);
    windowClass.hCursor = LoadCursor(0, IDC_ARROW);
    windowClass.hbrBackground = nullptr;
    windowClass.lpszMenuName = NULL;
    windowClass.lpszClassName = Window::ClassName;
    windowClass.hIconSm = LoadIcon(0, IDI_APPLICATION);

    RegisterClassEx(&windowClass);
    hwnd = CreateWindowEx(NULL, windowClass.lpszClassName, Window::WindowName, WS_POPUP | CW_USEDEFAULT, (GetSystemMetrics(SM_CXSCREEN) / 2) - (Gui::Size.x / 2), (GetSystemMetrics(SM_CYSCREEN) / 2) - (Gui::Size.y / 2), Gui::Size.x, Gui::Size.y, 0, 0, 0, 0);

    SetWindowLongA(hwnd, GWL_EXSTYLE, GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED);
    SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 255, LWA_ALPHA);

    MARGINS margins = { -1 };
    DwmExtendFrameIntoClientArea(hwnd, &margins);

    POINT mouse;
    rc = { 0 };
    GetWindowRect(hwnd, &rc);

    //RenderBlur(hwnd);

    // Initialize Direct3D
    if (!CreateDeviceD3D(hwnd))
    {
        CleanupDeviceD3D();
        ::UnregisterClass(windowClass.lpszClassName, windowClass.hInstance);
        return 1;
    }

    // Show the window
    ::ShowWindow(hwnd, SW_SHOWDEFAULT);
    ::UpdateWindow(hwnd);

    // Getting some shutdown stuff
    DWORD pid;
    GetWindowThreadProcessId(hwnd, &pid);
    HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pid);

    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    io.IniFilename = NULL; // Remove the imgui.ini

    ImGui::StyleColorsDark();

    ImGuiStyle& style = ImGui::GetStyle();

    style.WindowRounding = 10;

    // Setup Platform/Renderer backends
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    AddCustomDefaultFont(nullptr);

    // merge in icons from Font Awesome
    static const ImWchar icons_ranges[] = { ICON_MIN_FA, ICON_MAX_16_FA, 0 };
    static const ImWchar icons_ranges_brands[] = { ICON_MIN_FAB, ICON_MAX_16_FAB, 0 };
    ImFontConfig icons_config;
    IconFont = io.Fonts->AddFontFromMemoryTTF(Icons, sizeof(Icons), 23, NULL, io.Fonts->GetGlyphRangesCyrillic());
    IconFontLogs = io.Fonts->AddFontFromMemoryTTF(IconFontLog, sizeof(IconFontLog), 25, NULL, io.Fonts->GetGlyphRangesCyrillic());
    LexendDecaFont = io.Fonts->AddFontFromMemoryTTF(LexendDeca, sizeof(LexendDeca), 22, NULL, io.Fonts->GetGlyphRangesCyrillic());
    //InterMedium = io.Fonts->AddFontFromMemoryTTF(Intermedium, sizeof(Intermedium), 17, NULL, io.Fonts->GetGlyphRangesCyrillic());

    InterMediumone = io.Fonts->AddFontFromMemoryTTF(Intermedium, sizeof(Intermedium), 14, NULL, io.Fonts->GetGlyphRangesCyrillic());
    // Main loop
    bool loaderOpen = true;
    if (WinVersion::GetVersion(info) && info.Major <= 6)
    {
        MessageBox(hwnd, "your operating system is not supported", "Error", MB_ICONERROR);
    }
    else while ( loaderOpen && (info.Major > 6) )
    {
        // Poll and handle messages (inputs, window resize, etc.)
        // See the WndProc() function below for our to dispatch events to the Win32 backend.
        MSG msg;
        while (::PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
            {
                TerminateProcess(hProcess, 0);
                CloseHandle(hProcess);
            }
        }
        if (!loaderOpen)
        {
            break;
        }

        // Start the Dear ImGui frame
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        {std::string file_path = argv[1];
            ImGuiWindowFlags main_window_flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse;
            ImGui::SetNextWindowPos({0 , 0}, ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(Gui::Size);

            ImGui::Begin(Window::WindowName, &loaderOpen, main_window_flags); {
                UpdateWindowLocation();
                {ImGui::BeginGroup();
                {
                    ImGui::BeginChild("Launcher settings", ImVec2(300, 445), ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse); {




                        
                     
                    
                        
                        ImGui::Checkbox("Clean after closing", &var::CleanAClosing);
                        if (ImGui::IsItemHovered())
                        {
                //tooltip
                        }
                        ImGui::Checkbox("Reload explorer.exe after closing", &var::reloadEx);
                        ImGui::Checkbox("Crash minecraft after closing", &var::crash);
                        ImGui::Spacing();
                        ImGui::Spacing();
                        if (ImGui::Button("Safe launch", ImVec2(280,30)))
                        {
                          
                            std::thread process_thread(launchProcessThread, file_path);

                     
                            process_thread.detach();



                        }
                       
                 
                    }ImGui::EndChild();
                }ImGui::EndGroup();


                ImGui::SameLine();
                ImGui::BeginGroup();
                {

                    ImGui::BeginChild("Cleaner settings", ImVec2(300, 445), ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse); {




                        ImGui::Checkbox("Delete .exe", &var::delexe);
                        ImGui::Checkbox("Clean prefetch", &var::prefetch);
                        ImGui::Checkbox("Clean regedit", &var::regedit);
                        ImGui::Checkbox("Clean temp", &var::temp);
                        ImGui::Checkbox("Clean modification logs", &var::JournalDelete);

                        ImGui::Spacing();
                        ImGui::Spacing();
                        if (ImGui::Button("Clean", ImVec2(280, 30)))
                        {

                         

                            ShowWindow(consoleWindow, SW_SHOW);
                         

                            if (var::JournalDelete)
                                clearjournal();

                            if (var::delexe)
                                delexe(file_path);
                     
   Function(file_path, var::clean);

                        }
                        if (ImGui::Button("Reload explorer.exe", ImVec2(280, 30)))
                        {

                            reloadExp();


                        }

                        if (ImGui::Button("Check traces", ImVec2(280, 30)))
                        {
                            var::checking == true;
                               ShowWindow(consoleWindow, SW_SHOW);
                            Function1(file_path);
                          
                        }

                        if (ImGui::Button("Crash minecraft", ImVec2(280, 30)))
                            crash(file_path);
                 
                    
                   
                        if (ImGui::Button("Self-Destruct", ImVec2(280, 30)))
                            crash(file_path);

                    }ImGui::EndChild();
                }
                ImGui::EndGroup();
                }
            }
            ImGui::End();
        }

        // Rendering
        ImGui::Render();
       
        const float clear_color_with_alpha[4] = { 0 };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, NULL);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        g_pSwapChain->Present(1, 0); // Never set the 1 to 0 or the panel movment will get fucked
    }

    // Cleanup
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClass(windowClass.lpszClassName, windowClass.hInstance);

    return 0;
}

bool CreateDeviceD3D(HWND hWnd)
{
    // Setup swap chain
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    //createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    if (D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext) != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D()
{
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = NULL; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = NULL; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = NULL; }
}

void CreateRenderTarget()
{
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget()
{
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = NULL; }
}

// Forward declare message handler from imgui_impl_win32.cpp
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg)
    {
    case WM_SIZE:
        if (g_pd3dDevice != NULL && wParam != SIZE_MINIMIZED)
        {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
            CreateRenderTarget();
        }
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) // Disable ALT application menu
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProc(hWnd, msg, wParam, lParam);
}